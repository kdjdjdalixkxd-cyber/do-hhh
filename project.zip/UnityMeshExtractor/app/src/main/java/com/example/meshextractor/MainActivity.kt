package com.example.meshextractor

import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.documentfile.provider.DocumentFile
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

class MainActivity : AppCompatActivity() {

    private var inputUri: Uri? = null
    private var outputUri: Uri? = null

    private lateinit var status: TextView
    private lateinit var inputLabel: TextView
    private lateinit var outputLabel: TextView
    private lateinit var extractBtn: Button

    private val pickInput = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            inputUri = uri
            inputLabel.text = "الملف: " + (DocumentFile.fromSingleUri(this, uri)?.name ?: uri.toString())
            refresh()
        }
    }

    private val pickOutput = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            contentResolver.takePersistableUriPermission(
                uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                        android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
            outputUri = uri
            outputLabel.text = "المجلد: " + (DocumentFile.fromTreeUri(this, uri)?.name ?: uri.toString())
            refresh()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Python.isStarted()) Python.start(AndroidPlatform(this))

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.START
        }

        val pickInputBtn = Button(this).apply { text = "1) اختيار ملف Unity (.assets / .bundle / .unity3d)" }
        inputLabel = TextView(this).apply { text = "الملف: لم يتم الاختيار" }
        val pickOutputBtn = Button(this).apply { text = "2) اختيار مجلد الإخراج" }
        outputLabel = TextView(this).apply { text = "المجلد: لم يتم الاختيار" }
        extractBtn = Button(this).apply { text = "3) استخراج المجسمات"; isEnabled = false }
        status = TextView(this).apply { setPadding(0, pad, 0, 0) }

        pickInputBtn.setOnClickListener { pickInput.launch(arrayOf("*/*")) }
        pickOutputBtn.setOnClickListener { pickOutput.launch(null) }
        extractBtn.setOnClickListener { startExtract() }

        listOf(pickInputBtn, inputLabel, pickOutputBtn, outputLabel, extractBtn, status)
            .forEach { root.addView(it) }
        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun refresh() {
        extractBtn.isEnabled = inputUri != null && outputUri != null
    }

    private fun startExtract() {
        val inUri = inputUri ?: return
        val outUri = outputUri ?: return
        extractBtn.isEnabled = false
        status.text = "جاري الاستخراج..."

        Thread {
            val result = try {
                // 1) ننسخ الملف المختار إلى الكاش (بايثون يحتاج مسار عادي)
                val tmpIn = File(cacheDir, "input.bin")
                contentResolver.openInputStream(inUri)!!.use { i ->
                    tmpIn.outputStream().use { o -> i.copyTo(o) }
                }
                val tmpOut = File(cacheDir, "out").apply { deleteRecursively(); mkdirs() }

                // 2) استدعاء بايثون
                val py = Python.getInstance().getModule("extractor")
                val msg = py.callAttr("run", tmpIn.absolutePath, tmpOut.absolutePath).toString()

                // 3) ننسخ النتائج للمجلد اللي اختاره المستخدم
                val target = DocumentFile.fromTreeUri(this, outUri)!!
                var copied = 0
                tmpOut.listFiles()?.forEach { f ->
                    target.findFile(f.name)?.delete()
                    val doc = target.createFile("application/octet-stream", f.name)
                    if (doc != null) {
                        contentResolver.openOutputStream(doc.uri)!!.use { o ->
                            f.inputStream().use { it.copyTo(o) }
                        }
                        copied++
                    }
                }
                tmpIn.delete()
                tmpOut.deleteRecursively()
                "$msg\nتم نسخ $copied ملف إلى المجلد."
            } catch (e: Exception) {
                "خطأ: ${e.message}"
            }
            runOnUiThread {
                status.text = result
                refresh()
            }
        }.start()
    }
}
