import os
import re
import sys
import types
import traceback


class _Stub(types.ModuleType):
    """وحدة بديلة للمكتبات الثقيلة غير المتوفرة على أندرويد (تكستشر/صوت).
    المجسمات ما تحتاجها."""

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)

        def _unavailable(*a, **k):
            raise RuntimeError("%s.%s غير متوفر على أندرويد" % (self.__name__, name))

        return _unavailable


def _install_stubs():
    for mod in ("texture2ddecoder", "etcpak", "astc_encoder",
                "fmod_toolkit", "pyfmodex", "archspec"):
        try:
            __import__(mod)
        except Exception:
            sys.modules[mod] = _Stub(mod)


_install_stubs()


def _safe(name, fallback):
    name = re.sub(r"[^\w\-\.]+", "_", name or "").strip("_")
    return name or fallback


def _export(mesh):
    try:
        data = mesh.export()
    except Exception:
        from UnityPy.export import MeshExporter
        data = MeshExporter.export_mesh(mesh)
    if isinstance(data, bytes):
        data = data.decode("utf-8", "ignore")
    return data


def extract_meshes(src_path, out_dir):
    import UnityPy

    os.makedirs(out_dir, exist_ok=True)
    ok, failed, log = 0, 0, []

    env = UnityPy.load(src_path)
    for obj in env.objects:
        if obj.type.name != "Mesh":
            continue
        try:
            mesh = obj.read()
            name = _safe(getattr(mesh, "m_Name", ""), "mesh")
            data = _export(mesh)
            path = os.path.join(out_dir, "%s_%s.obj" % (name, obj.path_id))
            with open(path, "w", encoding="utf-8") as f:
                f.write(data)
            ok += 1
        except Exception as e:
            failed += 1
            log.append("فشل path_id=%s : %s" % (obj.path_id, e))
    return ok, failed, "\n".join(log)


def run(src_path, out_dir):
    try:
        ok, failed, log = extract_meshes(src_path, out_dir)
        msg = "تم استخراج %d مجسم" % ok
        if failed:
            msg += " (فشل %d)" % failed
        if ok == 0 and failed == 0:
            msg = "ما لقيت مجسمات (Mesh) في هذا الملف"
        return msg + ("\n" + log if log else "")
    except Exception:
        return "خطأ:\n" + traceback.format_exc()
