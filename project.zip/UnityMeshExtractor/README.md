# Unity Mesh Extractor (Android + Chaquopy + UnityPy)

1. افتح المجلد في Android Studio (Hedgehog أو أحدث) واتركه يزامن Gradle.
2. شغّل على جهاز حقيقي (arm64) أو محاكي x86_64.
3. من التطبيق: اختر ملف Unity > اختر مجلد الإخراج > استخراج.

الكود الرئيسي: app/src/main/python/extractor.py

لو فشل تثبيت UnityPy: افتح app/build.gradle.kts وغيّر رقم النسخة،
أو احذف السطر الخاص بحزمة لا تتوفر لها wheel على أندرويد.

## بناء APK عبر GitHub
ارفع المشروع لمستودع GitHub > تبويب Actions > Build APK > Run workflow.
بعد ما ينتهي، نزّل الـ APK من Artifacts أسفل الصفحة.
