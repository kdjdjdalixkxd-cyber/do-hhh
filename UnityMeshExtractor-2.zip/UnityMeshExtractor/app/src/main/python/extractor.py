import os
import re
import traceback


def _safe(name, fallback):
    name = re.sub(r"[^\w\-\.]+", "_", name or "").strip("_")
    return name or fallback


def extract_meshes(src_path, out_dir):
    """يستخرج كل الـ Mesh من ملف Unity ويحفظها OBJ داخل out_dir.
    يرجع (عدد الناجح, عدد الفاشل, رسائل)."""
    import UnityPy

    os.makedirs(out_dir, exist_ok=True)
    ok, failed, log = 0, 0, []

    env = UnityPy.load(src_path)
    for obj in env.objects:
        if obj.type.name != "Mesh":
            continue
        try:
            mesh = obj.read()
            name = _safe(getattr(mesh, "m_Name", ""), "mesh")
            data = mesh.export()
            if isinstance(data, bytes):
                data = data.decode("utf-8", "ignore")
            path = os.path.join(out_dir, "%s_%s.obj" % (name, obj.path_id))
            with open(path, "w", encoding="utf-8") as f:
                f.write(data)
            ok += 1
        except Exception as e:
            failed += 1
            log.append("فشل path_id=%s : %s" % (obj.path_id, e))
    return ok, failed, "\n".join(log)


def run(src_path, out_dir):
    """نقطة الدخول من Kotlin: ترجع نص جاهز للعرض."""
    try:
        ok, failed, log = extract_meshes(src_path, out_dir)
        msg = "تم استخراج %d مجسم" % ok
        if failed:
            msg += " (فشل %d)" % failed
        if ok == 0 and failed == 0:
            msg = "ما لقيت مجسمات (Mesh) في هذا الملف"
        return msg + ("\n" + log if log else "")
    except Exception:
        return "خطأ:\n" + traceback.format_exc()
